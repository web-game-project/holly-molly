module.exports = {
    socketConfig : {
        cors: {
            origin: '*',
            methods: ['GET', 'POST'],
        },
        allowEIO3: true,
    },
    jwtAccessKey: "Ho_LlYANdMOlly_accESS",
    jwtRefreshKey: "hO_LlYANdMOlly_RefRESH",
}
