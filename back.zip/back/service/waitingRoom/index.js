const changeUserReady = require('./changeUserReady');
const changeUserColor = require('./changeUserColor');
const exitWaitingRoom = require('./exitWaitingRoom');

module.exports = {
    changeUserReady,
    changeUserColor,
    exitWaitingRoom
}