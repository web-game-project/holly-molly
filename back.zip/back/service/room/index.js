const getRoomInfo = require('./getRoomInfo');
const editRoomInfo = require('./editRoomInfo');
const deleteRoom = require('./deleteRoom');

module.exports = {
    getRoomInfo,
    editRoomInfo,
    deleteRoom
}