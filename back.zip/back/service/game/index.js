const getInterimResult = require('./getInterimResult');
const getFinalResult = require('./getFinalResult');

module.exports = {
    getInterimResult,
    getFinalResult
}