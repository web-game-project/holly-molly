module.exports = async (socket, io, data) => {
    // 관련 로직 처리
    console.log(data.room_idx, data.color, data.previous_x, data.previous_y, data.current_x, data.current_y);
    io.to(data.room_idx).emit("draw", data);
};